#include <iostream>
#include <string>
#include <vector>
using namespace std;

#ifndef MUTUO_H
#define MUTUO_H
#include "Mutuo.h"
#endif

Mutuo::Mutuo(string valore, string scadenza, int periodicita){
	
}
