class Mutuo{
	private:
		string valore;
		string scadenza;
		int periodicita;
	
	public:
		Mutuo();
		Mutuo(string, string, int);
};
