#include <iostream>
#include <string>
#include <vector>
using namespace std;

#ifndef BANCA_H
#define BANCA_H
#include "Banca.h"
#endif


Banca::Banca(string nome){
	this->nome = nome;
}

Banca::accendiMutuo()
